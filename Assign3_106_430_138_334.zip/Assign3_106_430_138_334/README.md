<h1>Naive Bayes' Classifier</h1>
<h3>Applying Naive Bayes' Classifier to classify a given bitmap (whether it represents a face or not)</h3>
<b>Course Number :</b> BITS F464

<b>Contributors : </b>
<ul>
<li>G V Sandeep</li>
<li>Kushagra Agrawal</li>
<li>Snehal Wadhwani</li>
<li>Tanmaya Dabral</li>
</ul>

<h4> Instructions to use </h4>
<ol>
	<li> Compile Classifier.java file </li>
	<li> Execute Classifier.class file </li>
	<li> For further explanation and working of the program visit ML_Assign_3.pdf</li>
</ol>
